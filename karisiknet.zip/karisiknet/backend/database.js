// database.js - SQLite veritabanı bağlantısı
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Veritabanı dosyasının yolu
const dbPath = path.join(__dirname, 'database.sqlite');

// Veritabanı bağlantısını oluştur
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Veritabanı bağlantı hatası:', err.message);
    } else {
        console.log('✅ SQLite veritabanına bağlanıldı:', dbPath);
        
        // Temel tabloları oluştur
        initializeDatabase();
    }
});

// Temel tabloları oluştur
function initializeDatabase() {
    db.exec(`
        -- Kullanıcılar tablosu
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME,
            bio TEXT,
            avatar_url TEXT
        );
        
        -- Paylaşımlar tablosu
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            image_url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Site ayarları tablosu
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        
        -- Yorumlar tablosu (opsiyonel)
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id INTEGER,
            user_id INTEGER,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    `, (err) => {
        if (err) {
            console.error('❌ Tablo oluşturma hatası:', err);
        } else {
            console.log('✅ Temel tablolar oluşturuldu/hazır');
            
            // Varsayılan ayarları ekle
            insertDefaultSettings();
        }
    });
}

// Varsayılan ayarları ekle
function insertDefaultSettings() {
    const defaultSettings = [
        ['site_title', 'Kafa Karışık Studios'],
        ['hero_text', 'Teknoloji, tasarım ve yazılım dünyasına adım atın.'],
        ['about_text', 'Merhaba! Ben Kafa Karışık Studios. Teknoloji, yazılım ve tasarım üzerine içerikler üretiyorum.'],
        ['footer_text', '© 2026 produced by Kafa Karışık Studios'],
        ['youtube_url', 'https://www.youtube.com/channel/UCsSNuIOzgw60HAIuhLs7TyA']
    ];
    
    const stmt = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
    
    defaultSettings.forEach(([key, value]) => {
        stmt.run(key, value);
    });
    
    stmt.finalize();
    console.log('✅ Varsayılan ayarlar eklendi');
}

// Promise tabanlı sorgular için wrapper fonksiyonlar
db.prepareAsync = function(sql) {
    return new Promise((resolve, reject) => {
        const stmt = this.prepare(sql);
        resolve(stmt);
    });
};

db.runAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
};

db.getAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
};

db.allAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
};

// Veritabanını dışa aktar
module.exports = db;