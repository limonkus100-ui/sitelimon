const express = require('express');
const session = require('express-session');
const path = require('path');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const fs = require('fs');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// FRONTEND DOSYALARI
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

// UPLOADS KLASÖRÜNE ERİŞİM
app.use('/uploads', express.static(path.join(__dirname, '../frontend/uploads')));

// SESSION
app.use(session({
    secret: 'kafa-karisik-ozel-anahtar',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// VERİTABANI BAĞLANTISI
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

// ==================== VERİTABANI İNİTİALİZASYON ====================
async function initializeDatabase() {
    try {
        console.log('🔧 Veritabanı başlatılıyor...');
        
        // 1. TABLOLARI OLUŞTUR VEYA GÜNCELLE
        await createOrUpdateTables();
        
        // 2. DOSYA YÜKLEME KLASÖRÜNÜ OLUŞTUR
        const uploadsPath = path.join(__dirname, '../frontend/uploads');
        if (!fs.existsSync(uploadsPath)) {
            fs.mkdirSync(uploadsPath, { recursive: true });
            console.log('✅ Uploads klasörü oluşturuldu:', uploadsPath);
        }
        
        console.log('✅ Veritabanı hazır');
        
    } catch (error) {
        console.error('❌ Veritabanı başlatma hatası:', error);
    }
}

// ==================== TABLO OLUŞTURMA/GÜNCELLEME ====================
function createOrUpdateTables() {
    return new Promise((resolve, reject) => {
        db.serialize(() => {
            // 📁 FILES TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    originalname TEXT NOT NULL,
                    mimetype TEXT,
                    size INTEGER,
                    path TEXT,
                    url TEXT,
                    folder TEXT DEFAULT 'uploads',
                    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            `, (err) => {
                if (err) console.error('Files tablosu hatası:', err);
                else console.log('✅ Files tablosu hazır');
            });
            
            // 👥 USERS TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    role TEXT DEFAULT 'user',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_login DATETIME,
                    bio TEXT,
                    avatar_url TEXT,
                    full_name TEXT
                )
            `, (err) => {
                if (err) console.error('Users tablosu hatası:', err);
                else console.log('✅ Users tablosu hazır');
            });
            
            // 📝 POSTS TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS posts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    image_url TEXT,
                    files TEXT DEFAULT '[]',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    user_id INTEGER,
                    views INTEGER DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            `, async (err) => {
                if (err) {
                    console.error('Posts tablosu hatası:', err);
                    reject(err);
                } else {
                    console.log('✅ Posts tablosu hazır');
                    resolve();
                }
            });
            
            // ⚙️ SETTINGS TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            `, (err) => {
                if (err) console.error('Settings tablosu hatası:', err);
                else {
                    console.log('✅ Settings tablosu hazır');
                    
                    // Varsayılan ayarları ekle
                    const defaults = [
                        ['site_title', 'Kafa Karışık Studios'],
                        ['hero_text', 'Teknoloji, tasarım ve yazılım dünyasına adım atın.'],
                        ['about_text', 'Merhaba! Kafa Karışık Studios olarak teknoloji, yazılım ve tasarım üzerine içerikler üretiyoruz.'],
                        ['footer_text', '© 2026 produced by Kafa Karışık Studios'],
                        ['slogan_text', 'Karmaşık fikirler, basit çözümler']
                    ];
                    
                    defaults.forEach(([key, value]) => {
                        db.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [key, value]);
                    });
                }
            });
            
            // ❤️ LIKES TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS likes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    post_id INTEGER,
                    user_id INTEGER,
                    username TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(post_id, user_id),
                    FOREIGN KEY (post_id) REFERENCES posts(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            `, (err) => {
                if (err) console.error('Likes tablosu hatası:', err);
                else console.log('✅ Likes tablosu hazır');
            });
            
            // 💬 COMMENTS TABLOSU
            db.run(`
                CREATE TABLE IF NOT EXISTS comments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    post_id INTEGER,
                    user_id INTEGER,
                    username TEXT,
                    content TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (post_id) REFERENCES posts(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            `, (err) => {
                if (err) console.error('Comments tablosu hatası:', err);
                else console.log('✅ Comments tablosu hazır');
            });
        });
    });
}

// ==================== VERİTABANI FONKSİYONLARI ====================
function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
}

function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

// ==================== MULTER AYARLARI ====================
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join(__dirname, '../frontend/uploads');
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, uniqueSuffix + ext);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    fileFilter: (req, file, cb) => {
        cb(null, true);
    }
});

// ==================== AUTH MIDDLEWARE ====================
function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Giriş yapmalısınız' });
    }
    next();
}

function requireAdmin(req, res, next) {
    if (!req.session.userId || req.session.role !== 'admin') {
        return res.status(403).json({ error: 'Admin yetkisi gerekli' });
    }
    next();
}

// ==================== KULLANICI İŞLEMLERİ ====================
// Kullanıcı kayıt
app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        if (!username || !email || !password) {
            return res.status(400).json({ error: 'Tüm alanları doldurun' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ error: 'Şifre en az 6 karakter olmalı' });
        }
        
        // Kullanıcı adı ve email kontrolü
        const existingUser = await dbGet(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            [username, email]
        );
        
        if (existingUser) {
            return res.status(400).json({ error: 'Kullanıcı adı veya email zaten kullanımda' });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await dbRun(
            'INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)',
            [username, email, hashedPassword, username]
        );
        
        console.log(`✅ Yeni kullanıcı kaydı: ${username}`);
        res.json({ 
            success: true, 
            message: 'Kayıt başarılı!',
            userId: result.lastID 
        });
        
    } catch (err) {
        console.error('💥 Kayıt hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// Kullanıcı giriş
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: 'Kullanıcı adı ve şifre gerekli' });
        }
        
        const user = await dbGet(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            [username, username]
        );
        
        if (!user) {
            return res.status(401).json({ error: 'Kullanıcı bulunamadı' });
        }
        
        const isValid = await bcrypt.compare(password, user.password);
        
        if (!isValid) {
            return res.status(401).json({ error: 'Hatalı şifre' });
        }
        
        // Son giriş tarihini güncelle
        await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        
        // Session oluştur
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.role = user.role;
        
        console.log(`✅ Kullanıcı girişi: ${user.username}`);
        
        res.json({ 
            success: true, 
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                full_name: user.full_name,
                bio: user.bio,
                avatar_url: user.avatar_url
            }
        });
        
    } catch (err) {
        console.error('💥 Giriş hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// Çıkış
app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Çıkış yapılamadı' });
        }
        res.json({ success: true, message: 'Çıkış yapıldı' });
    });
});

// Profil bilgileri
app.get('/api/user/profile', requireAuth, async (req, res) => {
    try {
        const user = await dbGet('SELECT id, username, email, role, full_name, bio, avatar_url, created_at, last_login FROM users WHERE id = ?', [req.session.userId]);
        
        if (!user) {
            return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
        }
        
        res.json({ user });
    } catch (err) {
        console.error('Profil hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// ==================== DOSYA YÜKLEME API ====================
app.post('/api/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Dosya seçilmedi' });
        }
        
        const fileInfo = {
            filename: req.file.filename,
            originalname: req.file.originalname,
            mimetype: req.file.mimetype,
            size: req.file.size,
            path: req.file.path,
            url: `/uploads/${req.file.filename}`,
            folder: req.body.folder || 'uploads'
        };
        
        const sql = `
            INSERT INTO files (filename, originalname, mimetype, size, path, url, folder)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        
        const params = [
            fileInfo.filename,
            fileInfo.originalname,
            fileInfo.mimetype,
            fileInfo.size,
            fileInfo.path,
            fileInfo.url,
            fileInfo.folder
        ];
        
        db.run(sql, params, function(err) {
            if (err) {
                console.error('💥 Dosya kaydetme hatası:', err);
                return res.status(500).json({ error: 'Dosya kaydedilemedi' });
            }
            
            const savedFile = {
                id: this.lastID,
                ...fileInfo
            };
            
            console.log(`✅ Dosya yüklendi: ${fileInfo.originalname}`);
            res.json({ 
                success: true, 
                message: 'Dosya başarıyla yüklendi',
                file: savedFile
            });
        });
        
    } catch (err) {
        console.error('💥 Dosya yükleme hatası:', err);
        res.status(500).json({ error: 'Dosya yüklenemedi' });
    }
});

// ==================== POST İŞLEMLERİ ====================
// Yeni post oluşturma (EKSİK OLAN ENDPOINT)
app.post('/api/posts', requireAdmin, async (req, res) => {
    try {
        const { title, content, image_url, files } = req.body;
        
        if (!title || !content) {
            return res.status(400).json({ error: 'Başlık ve içerik gerekli' });
        }
        
        // Files JSON string'ine çevir
        const filesJson = files ? JSON.stringify(files) : '[]';
        
        const result = await dbRun(
            'INSERT INTO posts (title, content, image_url, files, user_id) VALUES (?, ?, ?, ?, ?)',
            [title, content, image_url || null, filesJson, req.session.userId]
        );
        
        console.log(`✅ Yeni post oluşturuldu: ${title}`);
        
        res.json({
            success: true,
            message: 'Post başarıyla oluşturuldu',
            postId: result.lastID
        });
        
    } catch (err) {
        console.error('💥 Post oluşturma hatası:', err);
        res.status(500).json({ error: 'Post oluşturulamadı' });
    }
});

// Tüm postları getir
app.get('/api/posts', async (req, res) => {
    try {
        console.log('📄 /api/posts çağrıldı');
        const posts = await dbAll('SELECT * FROM posts ORDER BY created_at DESC');
        
        // JSON string'i parse et
        const parsedPosts = posts.map(post => {
            try {
                let filesArray = [];
                
                if (post.files && post.files !== 'null' && post.files !== '[]') {
                    filesArray = JSON.parse(post.files);
                }
                
                return {
                    id: post.id,
                    title: post.title,
                    content: post.content,
                    image_url: post.image_url,
                    files: filesArray,
                    created_at: post.created_at,
                    updated_at: post.updated_at,
                    views: post.views || 0
                };
            } catch (error) {
                console.log(`Post ${post.id} JSON parse hatası:`, error.message);
                return {
                    id: post.id,
                    title: post.title,
                    content: post.content,
                    image_url: post.image_url,
                    files: [],
                    created_at: post.created_at,
                    updated_at: post.updated_at,
                    views: post.views || 0
                };
            }
        });
        
        console.log(`✅ ${parsedPosts.length} paylaşım gönderildi`);
        res.json(parsedPosts);
        
    } catch (err) {
        console.error('💥 Postları getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// Public postlar (arşiv için)
app.get('/api/public/posts', async (req, res) => {
    try {
        console.log('🌐 /api/public/posts çağrıldı');
        const posts = await dbAll('SELECT id, title, content, image_url, files, created_at FROM posts ORDER BY created_at DESC');
        
        const parsedPosts = posts.map(post => {
            try {
                let filesArray = [];
                
                if (post.files && post.files !== 'null' && post.files !== '[]') {
                    filesArray = JSON.parse(post.files);
                }
                
                return {
                    id: post.id,
                    title: post.title,
                    content: post.content,
                    image_url: post.image_url,
                    files: filesArray,
                    created_at: post.created_at
                };
            } catch (error) {
                return {
                    id: post.id,
                    title: post.title,
                    content: post.content,
                    image_url: post.image_url,
                    files: [],
                    created_at: post.created_at
                };
            }
        });
        
        console.log(`🌐 ${parsedPosts.length} paylaşım halka açık olarak gönderildi`);
        res.json(parsedPosts);
        
    } catch (err) {
        console.error('💥 Public posts hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// Post silme
app.delete('/api/posts/:id', requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const result = await dbRun('DELETE FROM posts WHERE id = ?', [id]);
        
        if (result.changes === 0) {
            return res.status(404).json({ error: "Paylaşım bulunamadı" });
        }
        
        // İlişkili beğenileri ve yorumları da sil
        await dbRun('DELETE FROM likes WHERE post_id = ?', [id]);
        await dbRun('DELETE FROM comments WHERE post_id = ?', [id]);
        
        console.log(`🗑️ Paylaşım silindi: ID ${id}`);
        res.json({ success: true });
    } catch (err) {
        console.error('💥 Silme hatası:', err);
        res.status(500).json({ error: "Veritabanı hatası" });
    }
});

// ==================== BEĞENİ İŞLEMLERİ ====================
app.post('/api/posts/:id/like', requireAuth, async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.session.userId;
        const username = req.session.username;
        
        // Post var mı kontrol et
        const post = await dbGet('SELECT id FROM posts WHERE id = ?', [postId]);
        if (!post) {
            return res.status(404).json({ error: 'Post bulunamadı' });
        }
        
        // Daha önce beğenmiş mi kontrol et
        const existingLike = await dbGet(
            'SELECT id FROM likes WHERE post_id = ? AND user_id = ?',
            [postId, userId]
        );
        
        let liked = false;
        
        if (existingLike) {
            // Beğeniyi kaldır
            await dbRun('DELETE FROM likes WHERE id = ?', [existingLike.id]);
        } else {
            // Beğeni ekle
            await dbRun(
                'INSERT INTO likes (post_id, user_id, username) VALUES (?, ?, ?)',
                [postId, userId, username]
            );
            liked = true;
        }
        
        // Beğeni sayısını al
        const likeCount = await dbGet(
            'SELECT COUNT(*) as count FROM likes WHERE post_id = ?',
            [postId]
        );
        
        res.json({
            success: true,
            liked: liked,
            likeCount: likeCount.count
        });
        
    } catch (err) {
        console.error('Beğeni hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// ==================== YORUM İŞLEMLERİ ====================
app.post('/api/posts/:id/comment', requireAuth, async (req, res) => {
    try {
        const postId = req.params.id;
        const { content } = req.body;
        
        if (!content || content.trim().length === 0) {
            return res.status(400).json({ error: 'Yorum içeriği gerekli' });
        }
        
        // Post var mı kontrol et
        const post = await dbGet('SELECT id FROM posts WHERE id = ?', [postId]);
        if (!post) {
            return res.status(404).json({ error: 'Post bulunamadı' });
        }
        
        // Yorumu ekle
        const result = await dbRun(
            'INSERT INTO comments (post_id, user_id, username, content) VALUES (?, ?, ?, ?)',
            [postId, req.session.userId, req.session.username, content.trim()]
        );
        
        res.json({
            success: true,
            commentId: result.lastID,
            message: 'Yorum eklendi'
        });
        
    } catch (err) {
        console.error('Yorum hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

app.get('/api/posts/:id/comments', async (req, res) => {
    try {
        const postId = req.params.id;
        
        const comments = await dbAll(
            'SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC',
            [postId]
        );
        
        res.json(comments);
        
    } catch (err) {
        console.error('Yorumları getirme hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// ==================== ADMIN İŞLEMLERİ ====================
// Admin girişi
app.post('/api/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: "Kullanıcı adı ve şifre gerekli" });
        }
        
        const user = await dbGet('SELECT * FROM users WHERE (username = ? OR email = ?) AND role = "admin"', [username, username]);
        
        if (!user) {
            return res.status(401).json({ error: "Admin kullanıcı bulunamadı" });
        }
        
        const isValid = await bcrypt.compare(password, user.password);
        
        if (!isValid) {
            return res.status(401).json({ error: "Hatalı şifre" });
        }
        
        await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.role = user.role;
        
        console.log(`✅ Admin giriş başarılı: ${user.username}`);
        
        res.json({ 
            success: true, 
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                isAdmin: true
            }
        });
    } catch (err) {
        console.error('💥 Admin giriş hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// Admin kontrolü
app.get('/api/check-setup', async (req, res) => {
    try {
        const result = await dbGet("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
        res.json({ hasAdmin: result.count > 0, adminCount: result.count });
    } catch (err) {
        console.error('❌ /api/check-setup hatası:', err);
        res.status(500).json({ hasAdmin: false, error: "Sunucu hatası" });
    }
});

// Admin kurulumu
app.post('/api/setup', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: "Kullanıcı adı ve şifre gerekli" });
        }
        
        if (password.length < 8) {
            return res.status(400).json({ error: "Şifre en az 8 karakter olmalı" });
        }
        
        const existing = await dbGet('SELECT * FROM users WHERE username = ?', [username]);
        if (existing) {
            return res.status(400).json({ error: "Bu kullanıcı adı zaten alınmış" });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await dbRun(
            `INSERT INTO users (username, password, role, email, full_name) VALUES (?, ?, 'admin', ?, ?)`,
            [username, hashedPassword, `${username}@admin.local`, username]
        );
        
        console.log(`✅ Admin hesabı oluşturuldu: ${username}`);
        res.json({ success: true, message: "Admin hesabı oluşturuldu", userId: result.lastID });
    } catch (err) {
        console.error('💥 Admin kurulum hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== ŞİFRE DEĞİŞTİRME ====================
app.post('/api/change-password', requireAuth, async (req, res) => {
    try {
        const { oldPassword, newPassword } = req.body;
        
        if (!oldPassword || !newPassword) {
            return res.status(400).json({ error: 'Tüm alanları doldurun' });
        }
        
        if (newPassword.length < 8) {
            return res.status(400).json({ error: 'Yeni şifre en az 8 karakter olmalı' });
        }
        
        // Mevcut şifreyi kontrol et
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [req.session.userId]);
        
        if (!user) {
            return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
        }
        
        const isValid = await bcrypt.compare(oldPassword, user.password);
        
        if (!isValid) {
            return res.status(400).json({ error: 'Mevcut şifre hatalı' });
        }
        
        // Yeni şifreyi hashle ve güncelle
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await dbRun('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, user.id]);
        
        console.log(`✅ Şifre değiştirildi: ${user.username}`);
        res.json({ success: true, message: 'Şifre başarıyla değiştirildi' });
        
    } catch (err) {
        console.error('Şifre değiştirme hatası:', err);
        res.status(500).json({ error: 'Sunucu hatası' });
    }
});

// ==================== AYARLAR ====================
app.get('/api/settings', async (req, res) => {
    try {
        const settings = await dbAll('SELECT * FROM settings');
        res.json(settings);
    } catch (err) {
        console.error('Ayarlar getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

app.post('/api/settings', requireAdmin, async (req, res) => {
    try {
        const settings = req.body;
        
        for (const [key, value] of Object.entries(settings)) {
            if (value !== undefined) {
                await dbRun('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
            }
        }
        
        console.log('✅ Ayarlar güncellendi');
        res.json({ success: true });
    } catch (err) {
        console.error('💥 Ayarlar hatası:', err);
        res.status(500).json({ error: "Veritabanı hatası" });
    }
});

// ==================== DEBUG ENDPOINT'LERİ ====================
app.get('/api/debug/posts', async (req, res) => {
    try {
        const posts = await dbAll('SELECT * FROM posts');
        
        res.json({
            count: posts.length,
            posts: posts.map(post => ({
                id: post.id,
                title: post.title,
                files: post.files,
                files_type: typeof post.files,
                files_length: post.files ? post.files.length : 0,
                created_at: post.created_at
            }))
        });
    } catch (err) {
        console.error('Debug hatası:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/debug/fix-all-posts', async (req, res) => {
    try {
        const posts = await dbAll('SELECT * FROM posts');
        let fixed = 0;
        
        for (const post of posts) {
            if (!post.files || post.files === '' || post.files === 'null') {
                await dbRun('UPDATE posts SET files = ? WHERE id = ?', ['[]', post.id]);
                fixed++;
            }
        }
        
        res.json({ 
            success: true, 
            message: `${fixed} kayıt düzeltildi`,
            fixed: fixed 
        });
    } catch (err) {
        console.error('Fix hatası:', err);
        res.status(500).json({ error: err.message });
    }
});

// ==================== SUNUCU BAŞLATMA ====================
const PORT = 3000;

// Önce veritabanını başlat, sonra sunucuyu başlat
initializeDatabase().then(() => {
    app.listen(PORT, () => {
        console.log(`
        ╔══════════════════════════════════════╗
        ║     🚀 Kafa Karışık Studios API     ║
        ║     http://localhost:${PORT}           ║
        ╚══════════════════════════════════════╝
        
        ✅ YENİ ENDPOINT'LER:
           👤 POST  /api/register            - Kullanıcı kayıt
           🔐 POST  /api/login               - Kullanıcı giriş
           🚪 POST  /api/logout              - Çıkış yap
           🔒 POST  /api/change-password     - Şifre değiştir
           📄 POST  /api/posts               - Yeni post oluştur
           ❤️  POST  /api/posts/:id/like     - Beğeni işlemi
           💬 POST  /api/posts/:id/comment   - Yorum ekle
           💬 GET   /api/posts/:id/comments  - Yorumları getir
        
        ✅ MEVCUT ENDPOINT'LER:
           📁 POST  /api/upload           - Dosya yükleme
           📄 GET   /api/posts            - Paylaşımları getir
           🗑️  DELETE /api/posts/:id       - Paylaşım sil
           🔐 POST  /api/admin-login      - Admin girişi
           🛠️  GET   /api/check-setup      - Admin kontrolü
           ⚙️  POST  /api/setup           - Admin kurulumu
           ⚙️  GET   /api/settings         - Ayarları getir
           ⚙️  POST  /api/settings         - Ayarları kaydet
        
        📁 Uploads klasörü: ${path.join(__dirname, '../frontend/uploads')}
        `);
    });
}).catch(err => {
    console.error('❌ Sunucu başlatılamadı:', err);
});