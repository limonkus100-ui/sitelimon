const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./database');
const bcrypt = require('bcrypt');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// FRONTEND DOSYALARI
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

// SESSION
app.use(session({
    secret: 'kafa-karisik-ozel-anahtar',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// ==================== VERITABANI FONKSIYONLARI ====================
function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
}

function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function dbExec(sql) {
    return new Promise((resolve, reject) => {
        db.exec(sql, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
}

// ==================== TABLO OLUŞTURMA ====================
console.log('🔧 Tablolar oluşturuluyor...');

dbExec(`
    -- Beğeniler tablosu (güncellenmiş)
    CREATE TABLE IF NOT EXISTS likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER,
        user_id INTEGER,
        username TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(post_id, user_id),
        FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    
    -- Görüntüleme istatistikleri tablosu
    CREATE TABLE IF NOT EXISTS views (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER,
        user_id INTEGER,
        ip_address TEXT,
        user_agent TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    
    -- Kullanıcılar tablosu
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME,
        bio TEXT,
        avatar_url TEXT
    );
    
    -- Paylaşımlar tablosu
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        image_url TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    
    -- Site ayarları tablosu
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );
`).then(() => {
    console.log('✅ Tüm tablolar hazır');
    
    // Varsayılan ayarları ekle
    const defaults = [
        ['site_title', 'Kafa Karışık Studios'],
        ['hero_text', 'Teknoloji, tasarım ve yazılım dünyasına adım atın.'],
        ['about_text', 'Merhaba! Ben Kafa Karışık Studios. Teknoloji, yazılım ve tasarım üzerine içerikler üretiyorum.'],
        ['footer_text', '© 2026 produced by Kafa Karışık Studios'],
        ['slogan_text', 'Karmaşık fikirler, basit çözümler'],
        ['youtube_url', 'https://www.youtube.com/channel/UCsSNuIOzgw60HAIuhLs7TyA']
    ];
    
    defaults.forEach(([key, value]) => {
        dbRun('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [key, value]);
    });
}).catch(err => {
    console.error('❌ Tablo oluşturma hatası:', err);
});

// ==================== KAYIT API ====================
app.post('/api/register', async (req, res) => {
    console.log('🎯 Kayıt isteği:', req.body.username);
    
    const { username, email, password } = req.body;
    
    if (!username || !email || !password) {
        return res.status(400).json({ error: "Tüm alanlar zorunludur" });
    }
    
    if (password.length < 6) {
        return res.status(400).json({ error: "Şifre en az 6 karakter olmalı" });
    }
    
    try {
        const existing = await dbGet('SELECT * FROM users WHERE username = ? OR email = ?', [username, email]);
        
        if (existing) {
            return res.status(400).json({ 
                error: existing.username === username ? 
                    "Bu kullanıcı adı alınmış" : 
                    "Bu email zaten kullanılıyor" 
            });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const result = await dbRun('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
            [username, email, hashedPassword]);
        
        console.log(`✅ Yeni kullanıcı: ${username} (ID: ${result.lastID})`);
        
        res.json({ 
            success: true, 
            message: "🎉 Kayıt başarılı! Giriş yapabilirsiniz.",
            userId: result.lastID 
        });
        
    } catch (err) {
        console.error('💥 Kayıt hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== GİRİŞ API ====================
app.post('/api/login', async (req, res) => {
    console.log('🔑 Admin giriş isteği:', req.body.username);
    
    const { username, password } = req.body;
    
    try {
        const user = await dbGet('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
        
        if (!user) {
            return res.status(401).json({ error: "Kullanıcı bulunamadı" });
        }
        
        const isValid = await bcrypt.compare(password, user.password);
        
        if (isValid) {
            await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
            
            req.session.userId = user.id;
            req.session.username = user.username;
            req.session.role = user.role;
            
            console.log(`✅ Giriş başarılı: ${user.username}`);
            
            res.json({ 
                success: true, 
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                }
            });
        } else {
            res.status(401).json({ error: "Hatalı şifre" });
        }
    } catch (err) {
        console.error('💥 Giriş hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== USER LOGIN API (login.html için) ====================
app.post('/api/user-login', async (req, res) => {
    console.log('👤 Kullanıcı giriş isteği:', req.body.username);
    
    const { username, password } = req.body;
    
    try {
        const user = await dbGet('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
        
        if (!user) {
            return res.status(401).json({ error: "Kullanıcı bulunamadı" });
        }
        
        const isValid = await bcrypt.compare(password, user.password);
        
        if (isValid) {
            await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
            
            req.session.userId = user.id;
            req.session.username = user.username;
            req.session.role = user.role;
            
            console.log(`✅ Kullanıcı girişi başarılı: ${user.username}`);
            
            res.json({ 
                success: true, 
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    created_at: user.created_at,
                    last_login: user.last_login
                }
            });
        } else {
            res.status(401).json({ error: "Hatalı şifre" });
        }
    } catch (err) {
        console.error('💥 Kullanıcı giriş hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== LOGOUT API ====================
app.post('/api/logout', (req, res) => {
    req.session.destroy();
    console.log('🚪 Çıkış yapıldı');
    res.json({ success: true, message: "Çıkış yapıldı" });
});

// ==================== CHECK SETUP API ====================
app.get('/api/check-setup', async (req, res) => {
    try {
        console.log('🔍 /api/check-setup çağrıldı');
        
        let admins;
        try {
            admins = await dbGet("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
            console.log('Admin sayısı:', admins.count);
        } catch (dbError) {
            console.error('Veritabanı hatası:', dbError);
            return res.status(500).json({ 
                hasAdmin: false, 
                error: "Veritabanı hatası",
                details: dbError.message 
            });
        }
        
        const response = { 
            hasAdmin: admins.count > 0,
            adminCount: admins.count,
            timestamp: new Date().toISOString()
        };
        
        console.log('API Yanıtı:', response);
        res.json(response);
        
    } catch (error) {
        console.error('❌ /api/check-setup hatası:', error);
        res.status(500).json({ 
            hasAdmin: false, 
            error: "Sunucu hatası",
            message: error.message 
        });
    }
});

// ==================== ADMIN SETUP API ====================
app.post('/api/setup', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: "Kullanıcı adı ve şifre gerekli" });
    }
    
    if (password.length < 8) {
        return res.status(400).json({ error: "Şifre en az 8 karakter olmalı" });
    }
    
    try {
        const existing = await dbGet('SELECT * FROM users WHERE username = ?', [username]);
        if (existing) {
            return res.status(400).json({ error: "Bu kullanıcı adı zaten alınmış" });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const result = await dbRun(
            `INSERT INTO users (username, password, role, email) VALUES (?, ?, 'admin', ?)`,
            [username, hashedPassword, `${username}@admin.local`]
        );
        
        console.log(`✅ Admin hesabı oluşturuldu: ${username}`);
        
        res.json({ 
            success: true, 
            message: "Admin hesabı oluşturuldu",
            userId: result.lastID 
        });
    } catch (err) {
        console.error('💥 Admin kurulum hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== BEĞENİ API ====================

// Beğeni ekle/çıkar
app.post('/api/posts/:id/like', async (req, res) => {
    console.log('👍 Beğeni isteği geldi:', req.params.id, req.session.userId);
    
    if (!req.session.userId) {
        return res.status(401).json({ 
            success: false, 
            error: "Giriş yapmalısınız" 
        });
    }
    
    const postId = parseInt(req.params.id);
    const userId = req.session.userId;
    const username = req.session.username;
    
    if (!postId || !userId) {
        return res.status(400).json({ 
            success: false, 
            error: "Geçersiz istek" 
        });
    }
    
    try {
        const post = await dbGet('SELECT * FROM posts WHERE id = ?', [postId]);
        if (!post) {
            return res.status(404).json({ 
                success: false, 
                error: "Paylaşım bulunamadı" 
            });
        }
        
        const existingLike = await dbGet('SELECT * FROM likes WHERE post_id = ? AND user_id = ?', [postId, userId]);
        
        if (existingLike) {
            await dbRun('DELETE FROM likes WHERE id = ?', [existingLike.id]);
            console.log(`👎 Beğeni kaldırıldı: Post ${postId}, User ${userId}`);
            
            const likeCount = await dbGet('SELECT COUNT(*) as count FROM likes WHERE post_id = ?', [postId]);
            
            res.json({ 
                success: true, 
                liked: false,
                message: "Beğeni kaldırıldı",
                likeCount: likeCount.count
            });
        } else {
            await dbRun('INSERT INTO likes (post_id, user_id, username) VALUES (?, ?, ?)', [postId, userId, username]);
            console.log(`👍 Beğeni eklendi: Post ${postId}, User ${userId} (${username})`);
            
            const likeCount = await dbGet('SELECT COUNT(*) as count FROM likes WHERE post_id = ?', [postId]);
            
            res.json({ 
                success: true, 
                liked: true,
                message: "Beğeni eklendi",
                likeCount: likeCount.count
            });
        }
        
    } catch (err) {
        console.error('❌ Beğeni hatası:', err);
        res.status(500).json({ 
            success: false, 
            error: "Sunucu hatası: " + err.message 
        });
    }
});

// Bir paylaşımın beğenilerini getir
app.get('/api/posts/:id/likes', async (req, res) => {
    const postId = parseInt(req.params.id);
    
    try {
        const likes = await dbAll(`
            SELECT l.*, u.username 
            FROM likes l 
            LEFT JOIN users u ON l.user_id = u.id 
            WHERE l.post_id = ? 
            ORDER BY l.created_at DESC
        `, [postId]);
        
        res.json(likes);
    } catch (err) {
        console.error('Beğenileri getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// Tüm beğenileri getir (admin için)
app.get('/api/admin/likes', async (req, res) => {
    if (!req.session.userId || req.session.role !== 'admin') {
        return res.status(401).json({ error: "Yetkiniz yok" });
    }
    
    try {
        const likes = await dbAll(`
            SELECT 
                l.id as like_id,
                l.created_at as like_date,
                p.id as post_id,
                p.title as post_title,
                u.id as user_id,
                u.username as username,
                u.email as email
            FROM likes l
            JOIN posts p ON l.post_id = p.id
            JOIN users u ON l.user_id = u.id
            ORDER BY l.created_at DESC
            LIMIT 100
        `);
        
        res.json(likes);
    } catch (err) {
        console.error('Admin beğenileri hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// Beğeni istatistikleri
app.get('/api/admin/likes/stats', async (req, res) => {
    if (!req.session.userId || req.session.role !== 'admin') {
        return res.status(401).json({ error: "Yetkiniz yok" });
    }
    
    try {
        const totalLikes = await dbGet('SELECT COUNT(*) as count FROM likes');
        
        const topPosts = await dbAll(`
            SELECT 
                p.id,
                p.title,
                COUNT(l.id) as like_count
            FROM posts p
            LEFT JOIN likes l ON p.id = l.post_id
            GROUP BY p.id
            ORDER BY like_count DESC
            LIMIT 10
        `);
        
        const topUsers = await dbAll(`
            SELECT 
                u.id,
                u.username,
                u.email,
                COUNT(l.id) as like_count
            FROM users u
            JOIN likes l ON u.id = l.user_id
            GROUP BY u.id
            ORDER BY like_count DESC
            LIMIT 10
        `);
        
        const weeklyTrend = await dbAll(`
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as count
            FROM likes
            WHERE created_at >= date('now', '-7 days')
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        `);
        
        res.json({
            totalLikes: totalLikes.count,
            topPosts,
            topUsers,
            weeklyTrend,
            statsTime: new Date().toISOString()
        });
        
    } catch (err) {
        console.error('İstatistik hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== CHANGE PASSWORD API ====================
app.post('/api/change-password', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    const { oldPassword, newPassword } = req.body;
    
    if (!oldPassword || !newPassword) {
        return res.status(400).json({ error: "Tüm alanlar zorunludur" });
    }
    
    if (newPassword.length < 8) {
        return res.status(400).json({ error: "Yeni şifre en az 8 karakter olmalı" });
    }
    
    try {
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [req.session.userId]);
        
        if (!user) {
            return res.status(404).json({ error: "Kullanıcı bulunamadı" });
        }
        
        const isValid = await bcrypt.compare(oldPassword, user.password);
        
        if (!isValid) {
            return res.status(401).json({ error: "Eski şifre hatalı" });
        }
        
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        
        await dbRun('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, req.session.userId]);
        
        console.log(`✅ Şifre değiştirildi: ${user.username}`);
        
        res.json({ success: true, message: "Şifre değiştirildi" });
    } catch (err) {
        console.error('💥 Şifre değiştirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== USER PROFILE API ====================
app.get('/api/user/profile', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    try {
        const user = await dbGet('SELECT id, username, email, role, created_at, last_login FROM users WHERE id = ?', [req.session.userId]);
        
        if (!user) {
            return res.status(404).json({ error: "Kullanıcı bulunamadı" });
        }
        
        res.json({ 
            success: true, 
            user: user
        });
    } catch (err) {
        console.error('💥 Profil getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== LOGIN HISTORY API ====================
app.get('/api/login-history', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    try {
        const history = await dbAll(`
            SELECT username, last_login 
            FROM users 
            WHERE role = 'admin' 
            ORDER BY last_login DESC 
            LIMIT 10
        `);
        
        res.json(history.map(item => ({
            username: item.username,
            login_time: item.last_login,
            ip_address: req.ip
        })));
    } catch (err) {
        console.error('💥 Geçmiş getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== SETTINGS API ====================
app.get('/api/settings', async (req, res) => {
    try {
        const settings = await dbAll('SELECT * FROM settings');
        res.json(settings);
    } catch (err) {
        console.error('Ayarlar getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

app.post('/api/settings', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    const settings = req.body;
    
    try {
        for (const [key, value] of Object.entries(settings)) {
            if (value !== undefined) {
                await dbRun('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
            }
        }
        
        console.log('✅ Ayarlar güncellendi');
        res.json({ success: true });
    } catch (err) {
        console.error('💥 Ayarlar hatası:', err);
        res.status(500).json({ error: "Veritabanı hatası" });
    }
});

// ==================== POSTS API ====================
app.get('/api/posts', async (req, res) => {
    try {
        const posts = await dbAll('SELECT * FROM posts ORDER BY created_at DESC');
        res.json(posts);
    } catch (err) {
        console.error('Postları getirme hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

app.post('/api/posts', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    const { title, content, image_url } = req.body;
    
    if (!title || !content) {
        return res.status(400).json({ error: "Başlık ve içerik zorunludur" });
    }
    
    try {
        const result = await dbRun('INSERT INTO posts (title, content, image_url) VALUES (?, ?, ?)', 
            [title, content, image_url || null]);
        
        console.log(`✅ Yeni paylaşım: ${title}`);
        res.json({ 
            success: true, 
            postId: result.lastID 
        });
    } catch (err) {
        console.error('💥 Paylaşım hatası:', err);
        res.status(500).json({ error: "Veritabanı hatası" });
    }
});

app.delete('/api/posts/:id', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Giriş yapmalısınız" });
    }
    
    const { id } = req.params;
    
    try {
        const result = await dbRun('DELETE FROM posts WHERE id = ?', [id]);
        
        if (result.changes === 0) {
            return res.status(404).json({ error: "Paylaşım bulunamadı" });
        }
        
        console.log(`🗑️ Paylaşım silindi: ID ${id}`);
        res.json({ success: true });
    } catch (err) {
        console.error('💥 Silme hatası:', err);
        res.status(500).json({ error: "Veritabanı hatası" });
    }
});

// ==================== TEST ENDPOINT ====================
app.get('/api/test', (req, res) => {
    res.json({ 
        status: 'online',
        time: new Date().toISOString(),
        message: 'Kafa Karışık Studios API çalışıyor!',
        endpoints: [
            'POST /api/register - Kullanıcı kaydı',
            'POST /api/login - Admin girişi',
            'POST /api/user-login - Kullanıcı girişi',
            'POST /api/logout - Çıkış',
            'GET  /api/check-setup - Admin kontrolü',
            'POST /api/setup - Admin kurulumu',
            'POST /api/change-password - Şifre değiştirme',
            'GET  /api/user/profile - Profil bilgileri',
            'GET  /api/login-history - Giriş geçmişi',
            'GET  /api/settings - Ayarları getir',
            'POST /api/settings - Ayarları kaydet',
            'GET  /api/posts - Paylaşımları getir',
            'POST /api/posts - Yeni paylaşım',
            'DELETE /api/posts/:id - Paylaşım sil'
        ]
    });
});

// ==================== 404 HANDLER ====================
app.use((req, res) => {
    console.log('❓ Bulunamayan endpoint:', req.method, req.url);
    res.status(404).json({ 
        error: "Endpoint bulunamadı: " + req.method + " " + req.url,
        availableEndpoints: [
            '/api/register',
            '/api/login', 
            '/api/user-login',
            '/api/logout',
            '/api/settings',
            '/api/posts',
            '/api/test'
        ]
    });
});

// ==================== ADMIN CHECK API ====================
app.get('/api/check-admin', async (req, res) => {
    try {
        const adminCount = await dbGet('SELECT COUNT(*) as count FROM users WHERE role = "admin"');
        res.json({ hasAdmin: adminCount.count > 0 });
    } catch (err) {
        console.error('Admin kontrol hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== ADMIN GIRIS API ====================
app.post('/api/admin-login', async (req, res) => {
    console.log('🔐 Admin giriş isteği:', req.body.username);
    
    const { username, password } = req.body;
    
    try {
        const user = await dbGet('SELECT * FROM users WHERE (username = ? OR email = ?) AND role = "admin"', [username, username]);
        
        if (!user) {
            return res.status(401).json({ 
                error: "Admin kullanıcı bulunamadı veya yetkiniz yok" 
            });
        }
        
        const isValid = await bcrypt.compare(password, user.password);
        
        if (isValid) {
            await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
            
            req.session.userId = user.id;
            req.session.username = user.username;
            req.session.role = user.role;
            
            console.log(`✅ Admin giriş başarılı: ${user.username}`);
            
            res.json({ 
                success: true, 
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    isAdmin: true
                }
            });
        } else {
            res.status(401).json({ error: "Hatalı şifre" });
        }
    } catch (err) {
        console.error('💥 Admin giriş hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== CREATE FIRST ADMIN (Alternatif) ====================
app.post('/api/create-first-admin', async (req, res) => {
    try {
        const adminCount = await dbGet('SELECT COUNT(*) as count FROM users WHERE role = "admin"');
        
        if (adminCount.count > 0) {
            return res.status(400).json({ 
                error: "Zaten bir admin hesabı var" 
            });
        }
        
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ 
                error: "Kullanıcı adı ve şifre gerekli" 
            });
        }
        
        if (password.length < 8) {
            return res.status(400).json({ 
                error: "Şifre en az 8 karakter olmalı" 
            });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const result = await dbRun(
            `INSERT INTO users (username, password, role, email) VALUES (?, ?, 'admin', ?)`,
            [username, hashedPassword, `${username}@admin.local`]
        );
        
        console.log(`✅ İlk admin oluşturuldu: ${username}`);
        
        res.json({ 
            success: true, 
            message: "İlk admin hesabı oluşturuldu!",
            username: username
        });
        
    } catch (err) {
        console.error('💥 Admin oluşturma hatası:', err);
        res.status(500).json({ error: "Sunucu hatası" });
    }
});

// ==================== SUNUCU ====================
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`
    ╔══════════════════════════════════════╗
    ║     🚀 Kafa Karışık Studios API     ║
    ║     http://localhost:${PORT}           ║
    ╚══════════════════════════════════════╝
    
    ✅ ÇALIŞAN ENDPOINT'LER:
       📝 POST  /api/register       - Kullanıcı kaydı
       🔑 POST  /api/login          - Admin girişi
       👤 POST  /api/user-login     - Kullanıcı girişi
       🚪 POST  /api/logout         - Çıkış yap
       🛠️  GET   /api/check-setup    - Admin kontrolü
       ⚙️  POST  /api/setup         - Admin kurulumu
       🔐 POST  /api/change-password - Şifre değiştir
       👤 GET   /api/user/profile   - Profil bilgileri
       📜 GET   /api/login-history  - Giriş geçmişi
       ⚙️  GET   /api/settings       - Ayarları getir
       ⚙️  POST  /api/settings       - Ayarları kaydet
       📄 GET   /api/posts          - Paylaşımları getir
       📄 POST  /api/posts          - Yeni paylaşım
       🗑️  DELETE /api/posts/:id     - Paylaşım sil
       🧪 GET   /api/test           - Test endpoint
       🔐 POST  /api/admin-login    - Admin girişi
       ⚙️  POST  /api/create-first-admin - İlk admin
       ❤️  POST  /api/posts/:id/like - Beğeni ekle/çıkar
       ❤️  GET   /api/posts/:id/likes - Beğenileri getir
       📊 GET   /api/admin/likes    - Admin beğeni listesi
       📈 GET   /api/admin/likes/stats - Beğeni istatistikleri
       👤 GET   /api/user/:id/likes - Kullanıcı beğenileri
       🔍 GET   /api/check-admin    - Admin kontrolü
    
    📁 Frontend: http://localhost:${PORT}
    👤 Kayıt:    http://localhost:${PORT}/register.html
    🔑 Giriş:    http://localhost:${PORT}/login.html
    ⚙️  Admin:    http://localhost:${PORT}/admin.html
    `);
});